import java.sql.Connection;
import java.sql.SQLException;

public class javaconnect {
    private static javaconnect instance;
    private Connection connection;

    public static javaconnect getInstance() {
        if (instance == null) {
            instance = new javaconnect();
        }
        return instance;
    }

    private javaconnect() {

    }

    public void connectToDatabase() throws SQLException {
        String server = "localhost";
        String port = "3305";
        String database = "chart_data";
        String userName = "raven";
        String password = "123";
        connection = java.sql.DriverManager.getConnection("jdbc:mysql://" + server + ":" + port + "/" + database, userName, password);
    }

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }   
}

