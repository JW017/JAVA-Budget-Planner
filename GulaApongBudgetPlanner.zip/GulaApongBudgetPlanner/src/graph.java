import java.sql.*;
import javax.swing.*;

package gulaapongbudgetplanner;

public class graph {

    private void buttonAnalysisActionPerformed(java.awt.event.ActionEvent evt){
        String url = "jdbc:mysql://localhost:3306/budgetwise";
        String username = "root";
        String password = "";
        String query = "select amount from income";

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection(url,username,password); 
                    Statement st = con.createStatement();
                    st.executeQuery(query);
                    ResultSet rset = st.executeQuery(query);

                    while (rset.next()){
                    String name = rset.getString("amount");

                    System.out.println(name);
                    connection.close();

                    }
                }catch(Exception e){
                System.out.print(e);
                }
        }
}