import javax.swing.*;
import java.awt.*;

public class LineGraph extends JPanel {
    private float[] dataPoints;

    public LineGraph(float[] dataPoints) {
        this.dataPoints = dataPoints;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Set the background color
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, getWidth(), getHeight());

        int xMargin = 40; // Margin from the left and right edges
        int yMargin = 40; // Margin from the top and bottom edges

        int width = getWidth() - 2 * xMargin; // Width of the graph area
        int height = getHeight() - 2 * yMargin; // Height of the graph area

        int numDataPoints = dataPoints.length;
        int xInterval = width / numDataPoints; // Interval between each x-coordinate

        // Find the maximum and minimum data points
        int maxDataPoint = Integer.MIN_VALUE;
        int minDataPoint = 0;
        for (int i = 0; i < numDataPoints; i++) {
            maxDataPoint = (int) Math.max(maxDataPoint, dataPoints[i]);
            minDataPoint = (int) Math.min(minDataPoint, dataPoints[i]);
        }

        // Calculate the y-scale to fit the data within the graph height
        double yScale = (double) height / (maxDataPoint - minDataPoint);

        // Draw the x and y axes
        g2d.setColor(Color.BLACK);
        g2d.drawLine(xMargin, yMargin + height, xMargin, yMargin); // Y-axis
        //g2d.drawString("Spending", 10, 10);
        g2d.drawString("Income (RM)", 10, 25);
        g2d.drawLine(xMargin, yMargin + height, xMargin + width, yMargin + height); // X-axis
        g2d.drawString("Days", 275, 230);
 


        // Draw the y-axis values
        int yTickCount = 5; // Number of tick marks on the y-axis
        double yInterval = (maxDataPoint - minDataPoint) / (double) (yTickCount - 1);
        for (int i = 0; i < yTickCount; i++) {
            int value = (int) (minDataPoint + i * yInterval);
            int y = yMargin + height - (int) (i * (height / (double) (yTickCount - 1)));
            g2d.drawString(String.valueOf(value), xMargin - 20, y);
        }

        // Draw the x-axis values
        int xTickCount = 31; // Number of tick marks on the x-axis
        
        for (int i = 0; i < xTickCount; i++) {
            if(i%5==0 && i!=0){
            String value = "Day " + (i);
            int x = xMargin + i * xInterval;

            // Rotate the x-axis values vertically
            Graphics2D g2dRotated = (Graphics2D) g2d.create();
            g2dRotated.translate(x, yMargin + height + 20);
            g2dRotated.rotate(-Math.PI / 2);
            g2dRotated.drawString(value, yMargin - 60, 0);
            g2dRotated.dispose();}
        }

        // Draw the data points and connect them with lines
        g2d.setColor(Color.BLUE);
        for (int i = 0; i < numDataPoints - 1; i++) {
            int x1 = xMargin + i * xInterval;
            int y1 = yMargin + height - (int) ((dataPoints[i] - minDataPoint) * yScale);
            int x2 = xMargin + (i + 1) * xInterval;
            int y2 = yMargin + height - (int) ((dataPoints[i + 1] - minDataPoint) * yScale);

            g2d.drawLine(x1, y1, x2, y2);
        }
    }

    public static void main(String[] args) {
        
        float[] dataPoints = {100.5f, 150.2f, 80.7f, 120.9f, 200.1f, 90.4f,100.5f, 150.2f, 80.7f, 120.9f, 200.1f, 90.4f,100.5f, 150.2f, 80.7f, 320.9f, 200.1f, 90.4f,100.5f, 150.2f, 80.7f, 120.9f, 200.1f, 90.4f,100.5f, 150.2f, 80.7f, 120.9f, 200.1f, 90.4f}; // Replace with your actual data
        
        JFrame frame = new JFrame("Line Graph");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(322, 300);

        LineGraph lineGraph = new LineGraph(dataPoints);
        frame.getContentPane().add(lineGraph);

        frame.setVisible(true);
    }
}
